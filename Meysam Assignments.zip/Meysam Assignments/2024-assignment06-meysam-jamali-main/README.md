[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-7f7980b617ed060a017424585567c406b6ee15c891e84e1186181d67ecf80aa0.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=14990851)
# Assignment 6
Follow the instructions at [assignment06.pdf](https://github.com/UCatDIBRIS/assignment06-2024/blob/main/assignment06.pdf)
