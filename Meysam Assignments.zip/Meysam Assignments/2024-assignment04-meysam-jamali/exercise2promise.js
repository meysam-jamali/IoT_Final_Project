'use strict';

const http = require('http');
const port = 8080;
const mainPath = '/?id=';
const devices = 10;

// Function to fetch data based on sensor Id
function sensorData(sensorId) {
  // Return a promise to handle asynchronous operations
  return new Promise((resolve, reject) => {
    // Setting options for the HTTP request
    const options = {
      hostname: 'localhost',
      port: port,
      path: `${mainPath}${sensorId}`,
      method: 'GET'
    };

    // Create the HTTP request
    const req = http.request(options, (res) => {
      let data = '';

      // Listener for fetching data
      res.on('data', (partialData) => {
        data += partialData;
      });

      // Listener for end of response
      res.on('end', () => {
        try {
          // Parse the received JSON data
          const parsedData = JSON.parse(data
          );
          resolve(parsedData); // Resolve the promise with the parsed data
        } catch (error) {
          reject(new Error(`Error parsing data for sensor ${sensorId}: ${error.message}`));
        }
      });
    });

    // Event listener for request errors
    req.on('error', (error) => {
      reject(new Error(`Error fetching data for sensor ${sensorId}: ${error.message}`));
    });

    // End the request
    req.end();
  });
}

// Function to find the first sensor with a defined value
function firstDefinedSensor() {
  let sensorId = 0;

  // Function to recursively fetch data for each sensor
  const nextSensorData = () => {
    // Check if all sensors have been checked
    if (sensorId >= devices) {
      console.log('No device found');
      return;
    }

    // Fetch data for the current sensor ID
    sensorData(sensorId)
      .then((response) => {
        // If response has a defined value
        if (response && response.value !== null) {
          // Represent the response
          console.log(response); 
        } else { // Move to the next sensor ID
          sensorId++; 
          nextSensorData(); // Recursively fetch data for the next sensor
        }
      })
      .catch((error) => { // Handle error
        console.error(error.message); 
        // Move to the next sensor ID
        sensorId++; 
        // Fetch next next sensor data
        nextSensorData(); 
      });
  };

  // Start fetching data for the first sensor - Crucial point - without this code the program not works
  nextSensorData();
}

// Call the function to find the first sensor with a defined value
firstDefinedSensor();
