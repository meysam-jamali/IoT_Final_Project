'use strict';

const http = require('http');
const port = 8080;
const mainPath = '/?id=';
const devices = 10;

// Function to fetch data based on sensor Id
function sensorData(sensorId) {
  // Return a promise to handle asynchronous operations
  return new Promise((resolve, reject) => {
    // Setting options for the HTTP request
    const options = {
      hostname: 'localhost',
      port: port,
      path: `${mainPath}${sensorId}`,
      method: 'GET'
    };

    // Create the HTTP request
    const req = http.request(options, (res) => {
      let data = '';

      // Listener for fetching data
      res.on('data', (partialData) => {
        data += partialData;
      });

      // Listener for end of response
      res.on('end', () => {
        try {
          // Parse the received JSON data
          const parsedData = JSON.parse(data);
          resolve(parsedData); // Resolve the promise with the parsed data
        } catch (error) {
          reject(new Error(`Error parsing data for sensor ${sensorId}: ${error.message}`));
        }
      });
    });

    // Event listener for request errors
    req.on('error', (error) => {
      reject(new Error(`Error fetching data for sensor ${sensorId}: ${error.message}`));
    });

    // End the request
    req.end();
  });
}

// Function to find the first sensor with a defined value
async function firstDefinedSensor() {
  // Sensor ID initilization
  let sensorId = 0;

  // Iterate through each sensor until a defined value is found
  while (sensorId < devices) {
    try {
      // Fetch data for the current sensor ID and wait to retrive all data
      const response = await sensorData(sensorId);
      // Check if the response contains a defined value and isn't null 
      if (response && response.value !== null) {
        // Represent the response
        console.log(response);
        return;
      } else { // Move to the next sensor due to lack of defined value
        sensorId++;
      }
    } catch (error) { // Handle the error
      console.error(error.message);
      // Move to the next sensor ID
      sensorId++; 
    }
  }

  console.log('No device found');
}

// Call the function to explore the first sensor with a defined value
firstDefinedSensor();