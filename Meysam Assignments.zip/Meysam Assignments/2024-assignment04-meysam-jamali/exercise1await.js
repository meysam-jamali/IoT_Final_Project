'use strict';

const http = require('http');
const port = 8080;
const mainPath = '/?id=';
const devices = 10;

// Function to retrieve sensor data
async function sensorData(sensorId) {
  // Specify the options for the HTTP request
  const options = {
    hostname: 'localhost',
    port: port,
    path: `${mainPath}${sensorId}`,
    method: 'GET'
  };

  return new Promise((resolve, reject) => {
    // Create the HTTP request
    const req = http.request(options, (res) => {
      let data = '';

      // Event listener for receiving data
      res.on('data', (partialData) => {
        data += partialData;
      });

      // Event listener for end of response
      res.on('end', () => {
        try {
          // Parse the received JSON data
          const parsedData = JSON.parse(data);
          resolve(parsedData); // Resolve the promise with the parsed data
        } catch (error) {
          reject(new Error(`Error parsing data for sensor ${sensorId}: ${error.message}`));
        }
      });
    });

    // Event listener for request errors
    req.on('error', (error) => {
      reject(new Error(`Error fetching data for sensor ${sensorId}: ${error.message}`));
    });

    // End the request
    req.end();
  });
}

// Compute median
function calculateMedian(arr) {
  // Eliminate null values
  const validValues = arr.filter(value => value !== null && !isNaN(value));
  
  // Sort the array
  validValues.sort((a, b) => a - b);

  // Calculate the length of the array
  const length = validValues.length;

  // Check if the array length is odd or even - based on median calculation way
  if (length % 2 === 0) {
    // If the length is even, return the average of the two middle values
    const middleIndex = length / 2;
    return (validValues[middleIndex - 1] + validValues[middleIndex]) / 2;
  } else {
    // If the length is odd, return the middle value
    const middleIndex = Math.floor(length / 2);
    return validValues[middleIndex];
  }
}

// Function to fetch sensors data to compute median
async function main() {
  const sensorValues = [];

  // Iterate through each sensor and fetch its data
  for (let i = 0; i < devices; i++) {
    try {
      // Retrive data for the current sensor and pending to retrieve all data
      const response = await sensorData(i);
      // Append the sensor data to the array
      sensorValues.push(response.value);
    } catch (error) { // Handle error
      console.error(error.message);
      
      // Add NaN to the array in case of error
      sensorValues.push(NaN);
    }
  }

  // Mediate computation for the array of sensor values
  const median = calculateMedian(sensorValues);
  console.log('Median:', median);
}

// Call the main function
main();
