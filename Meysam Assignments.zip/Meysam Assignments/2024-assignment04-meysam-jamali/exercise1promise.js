'use strict';

const http = require('http');
const port = 8080;
const mainPath = '/?id=';
const devices = 10;

// Function to fetch data based on sensor Id
function sensorData(sensorId) {
  // Return a promise to handle asynchronous operations
  return new Promise((resolve, reject) => {
    // Setting options for the HTTP request
    const options = {
      hostname: 'localhost',
      port: port,
      path: `${mainPath}${sensorId}`,
      method: 'GET'
    };

    // Create the HTTP request
    const req = http.request(options, (res) => {
      let data = '';

      // Listener for fetching data
      res.on('data', (partialData) => {
        data += partialData;
      });

      // Listener for end of response
      res.on('end', () => {
        try {
          // Parse the received JSON data
          const parsedData = JSON.parse(data);
          resolve(parsedData); // Resolve the promise with the parsed data
        } catch (error) {
          reject(new Error(`Error parsing data for sensor ${sensorId}: ${error.message}`));
        }
      });
    });

    // Event listener for request errors
    req.on('error', (error) => {
      reject(new Error(`Error fetching data for sensor ${sensorId}: ${error.message}`));
    });

    // End the request
    req.end();
  });
}

// Function to compute the sensor promises and calculate the median
function computeSensorData() {
  // Array to store promises for each sensor request
  const sensorPromises = [];

  // Iterate through each sensor and create a promise for each request
  for (let i = 0; i < devices; i++) {
    sensorPromises.push(sensorData(i));
  }

  // Execute all promises concurrently
  Promise.all(sensorPromises)
    .then((results) => {
      // Filter undefined and NaN values and extract defined sensor values from the results
      const sensorValues = results.map((result) => {
        return result && result.value !== undefined ? result.value : NaN;
      });

      // Compute the median of the sensor values
      const median = calculateMedian(sensorValues);
      console.log('Median:', median);
    })
    .catch((error) => { // Handle errors
      console.error('Error:', error.message); // Handle errors
    });
}

// Function to calculate the median of an array of numbers
function calculateMedian(sensorsArray) {
  // Eliminate null and NaN values
  const validValues = sensorsArray.filter(value => value !== null && !isNaN(value));
    
  // Sort the array
  validValues.sort((a, b) => a - b);
  
  // Extract the length of validValues array
  const length = validValues.length;
  // Check if the array length is odd or even - This condition is crucial for the calculation 
  // otherwise it won't work for assign2.json
  if (length === 0) {
    return NaN; // Return NaN if no valid values are found
  } else if (length % 2 === 0) {
    // If the length is even, return the average of the two middle values
    const midIndex = length / 2;
    return (validValues[midIndex - 1] + validValues[midIndex]) / 2;
  } else {
    // If the length is odd, return the middle value
    const midIndex = Math.floor(length / 2);
    return validValues[midIndex];
  }
}

// Call the function to compute sensor data
computeSensorData();
