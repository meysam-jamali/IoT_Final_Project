'use strict';

const http = require('http');
const port = 8080;
const devices = 10;

// Retrive sensor data by passing sensorId
function sensorData(sensorId) {
  // Resolve for final compeletion and reject for failure
  return new Promise((resolve, reject) => {
    // Specifing http request parameters
    const options = {
      hostname: 'localhost', // Server address
      port: 8080, // Server port
      path: `/?id=${sensorId}`, // Sensor ID
      method: 'GET' // Request Type
    };

    // Create http request
    const request = http.request(options, (res) => {
      // Initialization for returned data from the server
      let data = '';

      // Event listener for response stream (to be assured all data is recieved)
      res.on('data', (partial_data) => { 
        // Accumulate all data
        data += partial_data;
      });

      // When the all data collected 
      res.on('end', () => {
        // Convert data from JSON to string
        const parsedData = JSON.parse(data);
        // Resolve the promise with the parsed data
        resolve(parsedData);
      });
    });

    // Error handler
    request.on('error', (error) => {
      reject(error); // Reject the promise if there's an error
    });

    // End the request
    request.end();
  });
}

// Get all sensor values and calculate average
async function averageCalculation() {
  let sum = 0;
  let trueCount = 0; // Track the valid sensor values (null values are invalid)
  // Loop through each sensor
  for (let i = 0; i < devices; i++) {
    // Make a request for sensor(i) to get sensor data and wait for complete response
    const response = await sensorData(i);
    // Be sure the value of each each sensor is avaliable
    if (response && response.value !== null) {
      // Append the value of each sensor to sum (for average calculation)
      sum += response.value;
      trueCount++; // Increment trueCount by one (due to valid value data and not being null)
    }
  }
  // Average calculation 
  const average = sum / trueCount; // Calculate average using trueCount
  // Average Representation
  console.log("Average: " + average);
}

// Call the function to get sensor values and calculate average
averageCalculation();
