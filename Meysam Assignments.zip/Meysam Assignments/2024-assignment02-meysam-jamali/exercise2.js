const http = require('http');

// Retrieve sensor data by passing sensorId
function getSensorData(sensorId) {
  // Return a promise for eventual completion or failure
  return new Promise((resolve, reject) => {
    // Specify HTTP request parameters
    const options = {
      hostname: 'localhost', // Server address
      port: 8080, // Server port
      path: `/?id=${sensorId}`, // Sensor ID
      method: 'GET' // Request Type
    };

    // Create HTTP request
    const req = http.request(options, (res) => {
      // Initialize data variable to store server response
      let data = '';

      // Event listener for response stream (accumulating data)
      res.on('data', (partialData) => {
        data += partialData;
      });

      // Event listener for end of response stream
      res.on('end', () => {
        // Parse data and resolve the promise
        resolve(JSON.parse(data));
      });
    });

    // Error handler for the request
    req.on('error', (error) => {
      reject(error);
    });

    // End the request
    req.end();
  });
}

// Display information for the first sensor with a defined value
async function displayFirstSensorInfo() {
  // Specify the number of sensors
  const devices = 10; // Assuming you have 10 devices/sensors

  // Iterate through each sensor (from 0 to 9)
  for (let i = 0; i < devices; i++) {
    try {
      // Request data for sensor(i) and wait for the response
      const response = await getSensorData(i);
      
      // Check if sensor value is available
      if (response && response.value !== null) {
        // Print sensor information and exit loop
        console.log(response);
        break;
      }
    } catch (error) {
      console.error(`Error fetching data for sensor ${i}:`, error);
    }
  }
}

// Call the function to display information for the first sensor with a defined value
displayFirstSensorInfo();
