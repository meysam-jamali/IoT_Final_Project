'use strict';

const { connect } = require('mqtt');
const { createReadStream } = require('fs');
const { Transform } = require('stream');
const { createGunzip } = require('zlib');

const server = 'mqtt://212.78.1.205';
const topic = 'unige/dibris/iot23/assignment05';
const port = 1883;
const username = 'studenti';
const password = 'studentiDRUIDLAB_1';
const path = process.argv[2] || './room328.txt.gz'; 

// Connect to MQTT broker
const client = connect(server, { port, username, password });

client.on('connect', () => {
    console.log('Connected to MQTT server');

    // Read data from file and publish to MQTT
    const reader = createReadStream(path)
        .pipe(createGunzip()) // Unzip the compressed file
        .pipe(new Transform({
            transform(chunk, encoding, callback) {
                // Buffer to store data
                let buffer = '';
                // Convert buffer to string
                buffer += chunk.toString(); 
                // Split buffer into lines
                const lines = buffer.split('\n'); 
                // Remove last incomplete line from buffer
                buffer = lines.pop(); 

                // For each line
                lines.forEach(line => {
                    // Check if line is not empty
                    if (line.trim() !== '') { 
                        try {
                            // Parse JSON
                            const json = JSON.parse(line); 
                            // Publish JSON to MQTT
                            client.publish(topic, JSON.stringify(json)); 
                            // Represent the published json data
                            console.log('Data published to MQTT:', JSON.stringify(json));
                        } catch (error) { // Handle errors
                            console.error('Error parsing JSON:', error);
                        }
                    }
                });
                callback();
            }
        }));

    // Handle errors
    reader.on('error', err => {
        console.error('Error reading file:', err);
        client.end(); // Close MQTT connection
    });
});

// Handle MQTT connection errors
client.on('error', err => {
    console.error('Error connecting to MQTT server:', err);
});
