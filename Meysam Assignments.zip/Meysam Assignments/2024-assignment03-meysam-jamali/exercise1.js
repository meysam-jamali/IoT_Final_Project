'use strict';

const { request } = require('http');
const { parallel } = require('async');
const port = 8080;
const mainPath = '/?id=';
const devices = 10;

// Retrieve sensor data by passing sensorId
function sensorData(sensorId) {
  // Resolve for final completion and reject for failure
  return new Promise((resolve, reject) => {
    // Specify http request parameters
    const options = {
      hostname: 'localhost', // Server address
      port: port, // Server port
      path: `${mainPath}${sensorId}`, // Sensor ID
      method: 'GET' // Request Type
    };

    // Create http request
    const req = request(options, (res) => {
      // Initialization for returned data from the server
      let data = '';

      // Event listener for response stream (to be assured all data is received)
      res.on('data', (partial_data) => {
        // Accumulate all data
        data += partial_data;
      });

      // When all data is collected
      res.on('end', () => {
        // Convert data from JSON to an Object
        const parsedData = JSON.parse(data);
        // Resolve the promise with the parsed data
        resolve(parsedData);
      });
    });

    // Error handler
    req.on('error', (error) => {
      reject(error); // Reject the promise if there's an error
    });

    // End the request
    req.end();
  });
}

// Get all sensor values and calculate median
async function medianCalculation() {
    const array = [];
    // Loop through each sensor
    for (let i = 0; i < devices; i++) {
      // Make a request for sensor(i) to get sensor data and wait for complete response
      const response = await sensorData(i);
      // Be sure the value of each sensor is available and not null
      if (response && response.value !== null) {
        // Append the value of each sensor to the array
        array.push(response.value);
      }
    }

    // Median Calculation 
    // First step is sort the array ascending 
    array.sort((a, b) => a - b);
    // Median variable initialization
    let median;
    // Length of the array is computed
    const length = array.length;
    // If the array length is even
    if (length % 2 === 0) {
      // Average would be based on two middle array -> [middleIndex] and [middleIndex - 1]
      const middleIndex = length / 2;
      median = (array[middleIndex - 1] + array[middleIndex]) / 2;
    // If the array length is odd
    } else {
      // Only middle value is median
      const middleIndex = Math.floor(length / 2);
      median = array[middleIndex];
    }
    // Median Illustration
    console.log("Median: " + median);
}
  
// Call the function to get sensor values and calculate median
medianCalculation();
