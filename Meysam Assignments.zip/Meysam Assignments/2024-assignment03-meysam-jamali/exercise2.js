'use strict';

const http = require('http');
const async = require('async'); 
const port = 8080;
const mainPath = '/?id=';
let devices = 10; 

// Retrieve sensor data by passing sensorId
function sensorData(sensorId) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'localhost',
      port: port,
      path: `${mainPath}${sensorId}`,
      method: 'GET'
    };

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', (partialData) => {
        data += partialData;
      });

      res.on('end', () => {
        try {
          const parsedData = JSON.parse(data);
          resolve(parsedData); // Resolve with parsed data
        } catch (error) {
          reject(new Error(`Error parsing data for sensor ${sensorId}: ${error.message}`));
        }
      });
    });

    req.on('error', (error) => {
      reject(new Error(`Error fetching data for sensor ${sensorId}: ${error.message}`));
    });

    req.end();
  });
}

// Display information for the first sensor with a defined value
function displayFirstSensorInfo() {
  // Flag to track if sensor data is found
  let foundSensor = false; 
  // Initialize the counter for sensor IDs
  let i = 0; 

  async.whilst(
    // Test Function (Condition check) - Run the loop until data is found or all devices have been checked
    (callback) => {
      // Continue looping while not found and devices remain
      callback(null, !foundSensor && i < devices); 
    },
    // Function to execute on each iteration (sensor check)
    (next) => {
      sensorData(i)
        .then((response) => {
          // Check the response value for each sensor
          if (response && response.value !== null) {
            // Set flag if sensor data is found
            foundSensor = true; 
            // Represent the result
            console.log('Found sensor data:', response); 
          } else {
            console.log('The data is not available for sensor', i);
          }
          // Move to the next sensor ID
          i++; 
          // Continue loop to next sensor
          next(null); 
        })
        // Error handler
        .catch((error) => {
          console.error('Data can not be explored for sensor', i, ':', error.message);
          // Move to the next sensor ID
          i++; 
          // Continue looping to next sensor
          next(null); 
        });
    },
    // Final callback for error handling
    (err) => {
      if (err) {
        // Handle errors from the loop
        console.error('Error:', err); 
      } else if (!foundSensor) {
        // When data is not found
        console.log('No sensor data found with a defined value.'); 
      }
    }
  );
}

displayFirstSensorInfo();