'use strict';
const header = require('./header.json');
const data = require('./weather.json');

function toCSV(data) {
    // Extract headers from 'header' object
    const headers = Object.values(header);
    // Represent headers
    console.log(headers);

    // Convert data object into an array - iterate over each row as an item
    const rows = data.map(item => {
        // Extract values based on headers and address - iterate over each key in headers
        return headers.map(key => {
            // Explore the associated key in the object, whitespace, inconsistency, and case ssensitivity elimination
            const matchingKey = Object.keys(item).find(objKey => objKey.trim().toLowerCase() === key.trim().toLowerCase());
            // Return the value of the found key if it's avaliable otherwise empty 
            return matchingKey ? item[matchingKey] : '';
        });
    });

    // Constructing CSV string
    const csv = [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
    console.log(csv);
}

toCSV(data);
