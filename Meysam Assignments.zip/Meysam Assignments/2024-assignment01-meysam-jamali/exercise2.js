'use strict';

function stringify(object, propertises) {
    function replacer(key, value) {
        // Check value to be an object and not an array
        if(typeof(value) == 'object' && !Array.isArray(value)){
            // Define a transformative array to obtain desire propertises
            const temporal_object = {}

            // Traverse the propertise in value array
            for (const propertise in value){
                // To check propertise array whether contains each prop or not
                if(propertises(propertise)){
                    // Asign the value to the coresspond propertise
                    temporal_object[propertise] = value[propertise]
                }
            }
            return temporal_object
        }
        return value 
    }
    return JSON.stringify(object, replacer);
}


console.log(stringify([{ city: 'Milano', air_quality: 'red', temperature: 10 }, { air_quality: 'yellow', 'temperature': 20, 'sea_conditions': 3, city: 'Genova' }], k => k.match(/^[a-z]+$/)));
console.log(stringify([{ city: 'Milano', air_quality: 'red', temperature: 10 }, { air_quality: 'yellow', 'temperature': 20, 'sea_conditions': 3, city: 'Genova' }], k => k.length < 5));