'use strict';

// Stringify Override
function stringify(value) {
    // Second Argument Fabrication
    function replacer(key, value) {
        // Check Being An Array
        if (Array.isArray(value)) {
            // Check if array has non-numeric keys
            const keys = Object.keys(value);
            const hasNonNumericKeys = keys.some(k => isNaN(k));
            
            if (hasNonNumericKeys) {
                // Pseudo Array Creation
                const pseudo_array = {};

                // For Each Key In Value Array
                keys.forEach(k => {
                    pseudo_array[k] = (typeof value[k] === 'object' && value[k] !== null) ? JSON.parse(JSON.stringify(value[k])) : value[k];
                });
                return pseudo_array;
            }
            // If the array doesn't have non-numeric keys, return the original one
            return value;
        }

        // If value is not an array, return it as is
        return value;
    }
    return JSON.stringify(value, replacer);
}

let a1 = [{ city: 'Milano', air_quality: 'red', temperature: 10 }, { air_quality: 'yellow', 'temperature': 20, 'sea_conditions': 3, city: 'Genova' }];
let a2 = '2,3,5,7,9,11,13'.match(/\d+/);
let a3 = '2,3,5,7,9,11,13'.match(/\d+/g);

console.log(stringify({ a1, a2, a3 }));
